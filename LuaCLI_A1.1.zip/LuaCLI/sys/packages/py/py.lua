function CMD(args)
    if (#args < 2) then
        print("Usage: py <script.py> [args...]")
        return
    end
    if not file_exists(base_dir .. "sys/files/" .. args[2]) then
        print("File not found: " .. args[2])
        return
    end
    local has_python = os.execute("python --version >nul 2>&1")
    if has_python ~= 0 then
        print("Python is not installed or not found in PATH.")
        return
    end
    os.execute("python " .. base_dir .. "sys/files/" .. args[2] .. table.concat(args, " ", 3))
end