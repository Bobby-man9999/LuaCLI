function CMD(args)
    print("Hello, World!")
end