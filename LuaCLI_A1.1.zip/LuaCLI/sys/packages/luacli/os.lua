function CMD(args)
    table.remove(args, 1)
    args = table.concat(args, " ")
    os.execute(args)
end