function CMD(args)
    local lines = read_lines(base_dir .. "sys/data/version")
    print(lines[0])
end