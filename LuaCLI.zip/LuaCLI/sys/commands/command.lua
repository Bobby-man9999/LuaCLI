function CMD(args)
    print(args[2])
end