function CMD(args)
    restart()
end