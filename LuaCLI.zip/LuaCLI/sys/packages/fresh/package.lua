function CMD(args)
    if (args[2] == "install") then
        print("Installing package " .. args[3])
        install_package(args[3])
    elseif (args[2] == "copy") then
        print("Installing package " .. args[3])
        copy_files(base_dir .. "/sys/packages/" .. args[3], base_dir .. "/sys/commands")
    elseif (args[2] == "clear") then
        io.write("ARE YOU SURE? (Y/N) ")
        inp = io.read()
        if (inp == "Y" or inp == "y") then
            print("Purging...")
            purge(base_dir .. "/sys/commands")
            print("Installing fresh package...")
            copy_files(base_dir .. "sys\\packages\\fresh\\", base_dir .. "sys\\commands\\")
            print("Please install mainCMD to get the default commands back.")
        end
    elseif (args[2] == "set") then
        io.write("ARE YOU SURE? (Y/N) ")
        inp = io.read()
        if (inp == "Y" or inp == "y") then
            print("Purging...")
            purge(base_dir .. "/sys/commands")
            print("Installing " .. inp .. "package...")
            copy_files(base_dir .. "sys\\packages\\" .. inp, base_dir .. "sys\\commands\\")
        end
    end
    os.execute('del /F /Q "' .. base_dir .. 'sys/commands/install.lua"')
    print("Package command finished")
end