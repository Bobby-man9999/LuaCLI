function CMD(args)
    io.write("\n" .. args[2] .. args[2])
end