copy_files(base_dir .. "sys\\packages\\rando", base_dir .. "sys\\commands")
print("Thank you for using rando!")