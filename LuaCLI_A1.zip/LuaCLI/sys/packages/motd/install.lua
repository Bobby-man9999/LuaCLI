copy_file(base_dir .. "sys/packages/motd/motd.lua", base_dir .. "sys/commands/motd.lua")
copy_file(base_dir .. "sys/packages/motd/motd.txt", base_dir .. "sys/files/motd.txt")
