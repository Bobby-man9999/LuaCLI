function CMD(args)
    if (args[2] == "add") then
        print(args[3] + args[4])
    elseif (args[2] == "sub") then
        print(args[3] - args[4])
    elseif (args[2] == "mult") then
        print(args[3] * args[4])
    elseif (args[2] == "div") then
        print(args[3] / args[4])
    elseif (args[2] == "concat") then
        print(args[3] .. args[4])
    elseif (args[2] == "exp") then
        print(args[3] ^ args[4])
    elseif (args[2] == "sqr") then
        print(args[3] ^ args[3])
    end
end