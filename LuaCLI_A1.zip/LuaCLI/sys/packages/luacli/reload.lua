function CMD(args)
    refresh()
end