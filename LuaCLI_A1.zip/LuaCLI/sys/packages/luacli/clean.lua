function CMD(args)
    os.execute("cls")
end