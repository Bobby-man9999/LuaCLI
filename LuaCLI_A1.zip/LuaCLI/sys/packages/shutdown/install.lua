shutdown = io.open(base_dir .. "sys/shutdown/shutdown.lua", "w")
shutdowncsv = io.open(base_dir .. "sys/shutdown/shutdown.csv", "w")
shutdown:write([[files = io.open(base_dir .. "sys/shutdown/shutdown.csv", "r")
files = files:read("*all")
files = split(files, ",")
for _, file in ipairs(files) do
    local path = base_dir .. "sys/shutdown/" .. file
    if file:sub(-4) == ".lua" then
        local f = io.open(path, "r")
        if f then
            f:close()
            dofile(path)
        else
            print("Error: Could not open startup file: " .. path)
        end
    else
        print("Skipping non-Lua file in startup: " .. file)
    end
end]])
shutdowncsv:write("")
shutdown:close()
shutdowncsv:close()

main = io.open(base_dir .. "sys/main.lua", "a")
main:write([[
if (file_exists(base_dir .. "sys/shutdown/shutdown.lua")) then
    dofile(base_dir .. "sys/shutdown/shutdown.lua")
end
]])
main:close()