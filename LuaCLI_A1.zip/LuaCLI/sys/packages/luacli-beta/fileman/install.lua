copy_files(base_dir .. "/sys/packages/luacli-beta/fileman", base_dir .. "/sys/commands")
os.execute("mkdir \"" .. base_dir .. "sys\\files\"")
print("This package was made by ChatGPT. With edits from Fireshoa")