print('Test startup script')
